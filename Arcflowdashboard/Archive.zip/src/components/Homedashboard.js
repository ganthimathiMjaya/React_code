import React, { useState, useEffect, useCallback } from 'react';
import '../styles/bootstrap.css' // Line 6
import { DashBoardHomeLineChart, DashBoardHomeSlideChart, DashBoardHomeLineProduction } from './GenericCharts';
import axios from 'axios';
import PopupOpen from './Popup'
import '../styles/homedashboard.css';
import LoadingPanel from '../Common/CustomLoadingPanel';
import { Toast } from 'devextreme-react';
import { Tooltip } from 'react-tooltip';

const HomeDashBoard = ({ customerId, projectId, flowUserId, token }) => {
    // const [params, setParams] = useState({ customerId: 45, projectId: 1, FlowUserId: 51413, LoadTestData: 1, OrgId: 1, ClientId: 1, LobId: 1, FunctionalityId: 1 });
    const timeZones = [
        { Label: "IST", timeZone: "Asia/Kolkata" },
        { Label: "PHST", timeZone: "Asia/Manila" },
        { Label: "PST", timeZone: "America/Los_Angeles" },
        { Label: "MST", timeZone: "America/Denver" },
        { Label: "CST", timeZone: "America/Chicago" },
        { Label: "EST", timeZone: "America/New_York" },
    ];


    // State for production data
    const [productionDataState, setProductionDataState] = useState({
        chartDetails: {},
        chartData: [],
    });

    const [ProductDataCount, setProductDataCount] = useState({
        chartDetails: {},
        chartData: [],
    });

    //Qualtiy
    const [QualityData, setQualityData] = useState({
        chartDetails: {},
        chartData: [],
    });

    //Defects
    const [LocalDefectsTrendData, setDefectsTrendData] = useState({
        chartDetails: {},
        chartData: [],
    });

    //attendace
    const [AttendanceData, setAttendanceData] = useState({
        chartDetails: {},
        chartData: [],
    });

    //Testscore
    const [LocalTestScoreData, setLocalTestScoreData] = useState({
        chartDetails: {},
        chartData: [],
    });

    //Myworkspace
    const [MyWorkSapceData, setMyWorkSapceData] = useState({
        chartDetails: {},
        chartData: [],
    });

    //Default Load
    const [selectedData, setSelectedData] = useState("Today");
    const [currentTimes, setCurrentTimes] = useState({});
    const [knolnotificationcount, setknolnotificationcount] = useState(null);
    const [isPopupVisible, setIsPopupVisible] = useState(false);
    const [popupData, setpopupData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [projectidlist, setprojectidlist] = useState([])
    const [toastVisible, setToastVisible] = useState(false);
    const [toastMessage, setToastMessage] = useState('');
    const [toastType, setToastType] = useState('info');
    const [displayTime, setDisplayTime] = useState(1000);
    const AlertMessage = (message, type = 'info', displaytime = 1000) => {
        setToastMessage(message);
        setToastType(type);
        setToastVisible(true);
        setDisplayTime(displaytime)
    };


    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            await fetchProjectdetails(flowUserId, token);
            await fetchknolnotificationcount(flowUserId, customerId);
            setLoading(false);
        };

        fetchData();
        updateCurrentTimes();

        const timeInterval = setInterval(() => {
            updateCurrentTimes();
        }, 60000);

        return () => {
            clearInterval(timeInterval);
        };
    }, []); // Runs only once when the component mounts

    useEffect(() => {
        if (projectidlist && projectidlist.length > 0) {
            fetchDashboardData(projectidlist);

            const dashboardInterval = setInterval(() => {
                fetchDashboardData(projectidlist);
                setSelectedData('Today');
            }, 60000);

            return () => clearInterval(dashboardInterval);
        }
    }, [projectidlist]);



    const fetchProjectdetails = async (flowUserId, token) => {
        try {
            setLoading(true);
            //const authToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9lNjZmMWU2Yi05Y2I5LTQyNTgtYTQyOS0xNzhjZWUzNTlhYTkvIiwiaWF0IjoxNzM4ODQ5ODEzLCJuYmYiOjE3Mzg4NDk4MTMsImV4cCI6MTczODg1NDEyMSwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFZUUFlLzhaQUFBQVR4TGtJdTlQNUNlMks5d0ZrWXJDcmhmdUtBM0xiTm4wdFMzeUZodnd4M2VYNmduRzJldWJmUjZ3aklBdGhIWmI1RDdzaFpQdjZlekRySFJrazFqbUpueTk0SkNYVFgzak5aSVYzS2FZMUo4cUN4Rk5kYXZObGgrYktmNGlJOWJHUEFMazlXTzVGQ1VsSEs1bUdNeXZNK29oTndIYjFLREwyK2sxb3lHSkRwWT0iLCJhbXIiOlsicHdkIiwicnNhIiwibWZhIl0sImFwcF9kaXNwbGF5bmFtZSI6ImZsb3ctU1NPLWludGVncmF0aW9uIiwiYXBwaWQiOiI5MDA3ZTJjNC0zZWU5LTQxZDgtYmU3MS0zYWJkZDRlNzkzMjEiLCJhcHBpZGFjciI6IjEiLCJkZXZpY2VpZCI6ImM5MzZkYmNlLTg3ZjUtNDZkNC1iZjdlLTMwYzdlYjViMWJkMSIsImZhbWlseV9uYW1lIjoiQXJ1bGFuYW5kaGFtIiwiZ2l2ZW5fbmFtZSI6IkFydW5rdW1hciIsImlkdHlwIjoidXNlciIsImlwYWRkciI6IjJhMDk6YmFjMTozNmEwOjI0MDo6MTFiOjIiLCJuYW1lIjoiQXJ1bmt1bWFyIEFydWxhbmFuZGhhbSIsIm9pZCI6IjYwYjA5OTkxLWY4MzctNDEwZi05YzNmLWNmNTM1ZWYwZTJmMyIsIm9ucHJlbV9zaWQiOiJTLTEtNS0yMS0xNzcxMzgxNjgxLTI0NDc4MzgwMDItMzUxNDgyMDk4MS0yNTg4NjIiLCJwbGF0ZiI6IjMiLCJwdWlkIjoiMTAwMzIwMDNFNjEwQjVBQSIsInJoIjoiMS5BVk1BYXg1djVybWNXRUtrS1JlTTdqV2FxUU1BQUFBQUFBQUF3QUFBQUFBQUFBQlRBTGhUQUEuIiwic2NwIjoiRGlyZWN0b3J5LlJlYWQuQWxsIFVzZXIuUmVhZCBVc2VyLlJlYWQuQWxsIHByb2ZpbGUgb3BlbmlkIGVtYWlsIiwic2lkIjoiYWI1MWRhOTUtMmY5Zi00MzE3LTkzMDUtNzI3MDUzMjQyZDU2Iiwic2lnbmluX3N0YXRlIjpbImlua25vd25udHdrIiwia21zaSJdLCJzdWIiOiJUeHVNMlA2Wm9FV3FvTWJrRTlpQ0xDT0FmbE5qZFNhYkszSlkxV25ybjkwIiwidGVuYW50X3JlZ2lvbl9zY29wZSI6IkFTIiwidGlkIjoiZTY2ZjFlNmItOWNiOS00MjU4LWE0MjktMTc4Y2VlMzU5YWE5IiwidW5pcXVlX25hbWUiOiJhcnVua3VtYXIuYXJ1bGFAYWNjZXNzaGVhbHRoY2FyZS5jb20iLCJ1cG4iOiJhcnVua3VtYXIuYXJ1bGFAYWNjZXNzaGVhbHRoY2FyZS5jb20iLCJ1dGkiOiJaMEhncUsyLW5VaVMyM2dkT2U1WEFBIiwidmVyIjoiMS4wIiwid2lkcyI6WyJiNzlmYmY0ZC0zZWY5LTQ2ODktODE0My03NmIxOTRlODU1MDkiXSwieG1zX2Z0ZCI6Ii1yNEtzWXMxLWRYTGNiWkVkTU1Fc2F1QUdYV1lTcHRETmxmZnF4R29mMVkiLCJ4bXNfaWRyZWwiOiIxIDI0IiwieG1zX3N0Ijp7InN1YiI6Ii1ndDQ4RzF1OW9PczBjcDFYWS1VdVJUVENZTEVNdFBIU3dneVF6OTl1UG8ifSwieG1zX3RjZHQiOjE0MDE0NjM2MjUsIlVzZXJUeXBlIjoxLCJVc2VySWQiOjkyLCJFbXBJZCI6Ik8xMDY1MDU3IiwiRW1haWxJZCI6ImFydW5rdW1hci5hcnVsYUBhY2Nlc3NoZWFsdGhjYXJlLmNvbSIsIk5hbWUiOiJBcnVua3VtYXIgQXJ1bGFuYW5kaGFtIiwiQXBwS2V5IjoiMjllMWEyYTAtOGU0My00NDNhLTk4MDQtMTM3MGIwN2I3ZWRkIn0.XMKY-cqP1jXWJyQXq38by6UTCasA3aq_OerJuJ4dZxE"
            const authToken = token
            const apiUrlProjectCall = `https://iamapi.accesshealthcare.co/api/User/GetUserCustomerProjectMapping?UserId=${flowUserId}&OrgId=9ba8241f-ab2c-4c1b-98be-81a97b165f00&token=${authToken}`;

            const response = await axios.get(apiUrlProjectCall, {
                headers: {
                    Authorization: `Bearer ${authToken}`  // Add token here
                }
            });

            if (response.data && response.data.Success && response.data.Data?.CustomerList) {
                const projectIds = response.data.Data.CustomerList.flatMap(customer =>
                    customer.ProjectList.map(project => project.ProjectId)
                );
                setprojectidlist(projectIds);
                console.log('projectidlist', projectidlist);
                //alert(projectidlist)
            }
        } catch (error) {
            console.error("Error fetching project details:", error);
        } finally {
            setLoading(false);
        }
    };


    const fetchknolnotificationcount = async (flowUserId, customerId) => {
        const apiUrl = `https://knolapi.accesshealthcare.co/api/ArticleDashboard/GetUserArticleCountsByCustomersAndProjects`;

        const requestBody = {
            LoggedUserId: flowUserId,  // Ensure FlowUserId is defined
            Params: {
                CustomerIds: Array.isArray(customerId) ? customerId : [customerId],  // Ensure array format
                ProjectIds: Array.isArray(projectidlist) ? projectidlist : [projectidlist],  // Ensure array format
            },
        };
        try {
            setLoading(true);
            const response = await axios.post(apiUrl, requestBody);
            if (response?.data?.Success && Array.isArray(response.data.Data)) {
                const notificationData = response.data.Data[0] || null;
                setknolnotificationcount(notificationData);
                console.log("knolnotificationcount", knolnotificationcount)
                //console.log("Notification data fetched successfully:", notificationData);
            } else {
                console.error("Failed to fetch notification data. Success:", response?.data?.Success);
            }
        } catch (error) {
            console.error("Error fetching notification data:", error);
        } finally {
            setLoading(false);
        }
    };


    const fetchDashboardData = (projectidlist) => {
        if (!projectidlist || projectidlist.length === 0) {
            AlertMessage("no data found", "warning", 3000);
            return;
        }

        setLoading(true);
        const apiUrl = `https://arcflowcustomeronboardingapi.accesshealthcare.co/api/HomeUserDashboard/GetHomeUserDashboardChartData?FlowUserId=${flowUserId}`;

        axios
            .post(apiUrl, projectidlist)
            .then((response) => {
                if (response.data != null && typeof response.data === 'object') {
                    const ProductionDataResponse = response.data.ProductionData || {};
                    setProductionDataState({
                        chartDetails: ProductionDataResponse.ChartDetails || {},
                        chartData: ProductionDataResponse.ChartData
                            ? ProductionDataResponse.ChartData.filter((item) => item.FieldCategory === "Today")
                            : [],
                    });

                    const Productcountresponse = response.data.ProductionData || {};
                    setProductDataCount({
                        chartDetails: Productcountresponse.ChartDetails || {},
                        chartData: Productcountresponse.ChartData || [],
                    });

                    const qualityDataResponse = response.data.QualityData || {};
                    setQualityData({
                        chartDetails: qualityDataResponse.ChartDetails || {},
                        chartData: qualityDataResponse.ChartData || [],
                    });

                    const DefectsTrendData = response.data.DefectsTrendData || {};
                    setDefectsTrendData({
                        chartDetails: DefectsTrendData.ChartDetails || {},
                        chartData: Array.isArray(DefectsTrendData.ChartData) ? DefectsTrendData.ChartData : [],
                    });

                    const AttendanceResponse = response.data.AttendanceData || {};
                    setAttendanceData({
                        chartDetails: AttendanceResponse.ChartDetails || {},
                        chartData: AttendanceResponse.ChartData || [],
                    });

                    const LocTestScoreData = response.data.TestScoreData || {};
                    setLocalTestScoreData({
                        chartDetails: LocTestScoreData.ChartDetails || {},
                        chartData: LocTestScoreData.ChartData || [],
                    });

                    const MyWorkSpaceresponse = response.data.MyWorkSpaceData || {};
                    setMyWorkSapceData({
                        chartDetails: MyWorkSpaceresponse.ChartDetails || {},
                        chartData: MyWorkSpaceresponse.ChartData || [],
                    });
                }
            })
            .catch((error) => console.error("Error fetching dashboard data:", error))
            .finally(() => {
                setLoading(false); // End the loading state
            });
    };




    // Production Chartcount
    const ProductTodayCount =
        ProductDataCount?.chartData?.find(
            (item) => item.FieldCategory === "Today"
        )?.FieldData ?? 0;

    const ProductThisWeekCount =
        ProductDataCount?.chartData?.find(
            (item) => item.FieldCategory === "This Week"
        )?.FieldData ?? 0;

    const ProductMTDCount =
        ProductDataCount?.chartData?.find(
            (item) => item.FieldCategory === "MTD"
        )?.FieldData ?? 0;


    // Production Chart today, thisweek, mtd change event
    const handleSpanClick = (key) => {
        if (ProductDataCount.chartData) {
            const filteredData = ProductDataCount.chartData.filter(
                (item) => item.FieldCategory === key
            );
            if (filteredData.length > 0) {
                if (selectedData !== key) {
                    setSelectedData(key);
                }
                setProductionDataState({
                    ...productionDataState,
                    chartData: filteredData,
                });
            } else {
                console.warn(`No data found for "${key}" in chartData.`);
            }
        } else {
            console.warn(`No chartData found in productionDataState.`);
        }
    };

    // Define `updateCurrentTimes` using useCallback
    const updateCurrentTimes = useCallback(() => {
        const times = {};
        timeZones.forEach(({ Label, timeZone }) => {
            const time = new Intl.DateTimeFormat("en-US", {
                timeZone,
                hour: "2-digit",
                minute: "2-digit"
            }).format(new Date());
            times[Label] = time;
        });
        setCurrentTimes(times);
    }, [timeZones]); // Add `timeZones` as a dependency





    console.log(QualityData.chartData)
    //ValueFields of QualityData
    // const QualityDatavalueFields =
    //   QualityData.chartData &&
    //     QualityData.chartData.length > 0 &&
    //     QualityData.chartData[1].FieldListData &&
    //     QualityData.chartData[1].FieldListData.length > 0
    //     ? Object.keys(QualityData.chartData[1].FieldListData[0].FieldListData || {})
    //     : [];

    const QualityDatavalueFields =
        QualityData?.chartData?.[0]?.FieldListData?.[0]?.FieldListData
            ? Object.keys(QualityData.chartData[0].FieldListData[0].FieldListData)
            : [];




    //Bar ClickEvent
    const onBarClick = async (e) => {
        const clickedValue = e.target.value;
        if (!clickedValue) {
            console.error("Clicked category is undefined");
            return;
        }
        const apiUrlOriginalCall = 'api/HomeUserDashboard/GetHomeUserDashboardChartData?ProjectId=1&FlowUserId=51413&LoadTestData=1';
        try {
            setpopupData([]);
            setIsPopupVisible(false);

            const response = await axios.get(apiUrlOriginalCall);
            if (response.data && response.data.homeUserDashboardRawDatas) {
                setpopupData(response.data.homeUserDashboardRawDatas);
                setIsPopupVisible(true); // Open the popup
            } else {
                console.error("Invalid or empty API response");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };



    return (
        <div>
            {/* <Sidenav /> */}
            {/* <Header /> */}
            <Toast
                visible={toastVisible}
                message={toastMessage}
                type={toastType}
                displayTime={displayTime}
                onHiding={() => setToastVisible(false)}
            />

            <LoadingPanel loading={loading} />
            <div className="overallchart">
                <div className="chartfourpanel">
                    {/* Box 1 */}
                    <div className="box1">
                        <div className="chartcardbox production">
                            <div className="d_header_section">
                                <h4>{productionDataState.chartDetails.Title}</h4>
                                <div>
                                    <span className="chartsdp">SDPS : 80</span>
                                </div>
                            </div>
                            <div>
                                {productionDataState.chartData && productionDataState.chartData.length > 0 ? (
                                    <>
                                        {/* Render the production chart */}
                                        <DashBoardHomeLineProduction
                                            data={productionDataState.chartData}
                                            title={productionDataState.chartDetails?.Title || "Production Data"}
                                            argumentField="FieldCategory"
                                            chartHeight={'calc(100vh / 1.8)'}
                                            onPointClick={onBarClick}

                                        />

                                        {/* Conditionally render the popup */}
                                        {isPopupVisible && (
                                            <PopupOpen
                                                visible={isPopupVisible}
                                                dataSource={popupData} // Pass API data here
                                            />
                                        )}
                                    </>
                                ) : (
                                    <div style={{ height: 'calc(100vh / 2.2)' }}>
                                        <p style={{ textAlign: 'center', fontSize: '14px', fontWeight: 'bold' }}>
                                            No data available...
                                        </p>
                                    </div>
                                )}
                            </div>
                            <div>
                                <div className="chartdays">
                                    <div
                                        className={`chartduration ${selectedData === "Today" ? "active" : ""}`}
                                        onClick={() => handleSpanClick("Today")}
                                    >
                                        <h5>
                                            <b>Today</b>
                                        </h5>
                                        <span>{ProductTodayCount}</span>
                                    </div>

                                    <div
                                        className={`chartduration ${selectedData === "This Week" ? "active" : ""}`}
                                        onClick={() => handleSpanClick("This Week")}
                                    >
                                        <h5>
                                            <b>This Week</b>
                                        </h5>
                                        <span>{ProductThisWeekCount}</span>
                                    </div>

                                    <div
                                        className={`chartduration ${selectedData === "MTD" ? "active" : ""}`}
                                        onClick={() => handleSpanClick("MTD")}
                                    >
                                        <h5>
                                            <b>MTD</b>
                                        </h5>
                                        <span>{ProductMTDCount}</span>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div className="chartcardbox time">
                            <h4>Time</h4>
                            <div className="chartimelevel">
                                {timeZones.map(({ Label }) => (
                                    <div className="chartimebox" key={Label}>
                                        <h5>{Label}</h5>
                                        <span>{currentTimes[Label]}</span>
                                    </div>
                                ))}

                            </div>
                        </div>
                    </div>

                    {/* Box 2 */}
                    <div className="box2">
                        <div className="chartcardbox quality">
                            <div className="d_header_section">
                                <h4>{QualityData.chartDetails.Title}</h4>
                                <div>
                                    <span className="chartsdp">SDPS : 80</span>
                                </div>
                            </div>
                            <div>
                                {QualityData.chartData?.length > 0 && QualityData.chartData.some(item => item.FieldData > 0) ? (
                                    <DashBoardHomeLineChart
                                        data={QualityData.chartData}
                                        title={QualityData.chartDetails.Title}
                                        argumentField="FieldCategory"
                                        valueFields={QualityDatavalueFields}
                                        chartHeight={'calc(100vh / 3)'}
                                        onPointClick={(e) => console.log(e.target)}
                                    />
                                ) : (
                                    <div className="no-data-message">
                                        <p style={{ textAlign: "center", fontSize: "14px", fontWeight: "bold" }}>
                                            No data available...
                                        </p>
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="chartcardbox quality">
                            {LocalDefectsTrendData.chartDetails && (
                                <div className="d_header_section">
                                    <h4>{LocalDefectsTrendData.chartDetails.Title}</h4>
                                    <div className='Homedashboard'>
                                        <span className="chartsdp">SDPS : 80</span>
                                    </div>
                                </div>
                            )}
                            <div>
                                {LocalDefectsTrendData.chartData?.length > 0 && LocalDefectsTrendData.chartData.some(item => item.FieldData > 0) ? (
                                    <DashBoardHomeSlideChart
                                        data={LocalDefectsTrendData.chartData}
                                        argumentField="FieldCategory"
                                        valueFields={['FieldData']}
                                        chartHeight={'calc(100vh / 3)'}
                                        onPointClick={(e) => console.log(e.target)}
                                    />
                                ) : (
                                    <div className="no-data-message">
                                        <p style={{ textAlign: "center", fontSize: "14px", fontWeight: "bold" }}>
                                            No data available...
                                        </p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Box 3 */}
                    <div className="box3">


                        <div className='chartcardbox workplace'>
                            <div className='d_header_section' style={{ paddingBottom: '0px' }}>
                                <h4>{MyWorkSapceData.chartDetails.Title}</h4>


                            </div>
                            <div class="workplacebox">

                                {/* <div className="workplacebox">
                                    {MyWorkSapceData.chartData[0]?.FieldListData?.map((project, index) => (
                                        <div className="workplacecontent" key={index}>
                                            <h4>{project.FieldData}</h4>
                                            <span>{project.FieldCategory}</span>
                                        </div>
                                    ))}

                                </div> */}
                                {/* <div className="workplacebox" >
                                    {MyWorkSapceData.chartData[0]?.FieldListData?.map((project, index) => (
                                        <div className="workplacecontent" key={index}>
                                            <span className='d_header_section' dangerouslySetInnerHTML={{ __html: project.FieldCategory.replace(/<\/?br\s*\/?>/gi, "<br>") }} />
                                            <h4 style={{ textAlign: 'left' }}>{project?.FieldData}</h4>

                                        </div>
                                    ))}
                                </div> */}
                                <div className="workplacebox">
                                    {MyWorkSapceData.chartData[0]?.FieldListData?.map((project, index) => {
                                        const parts = project.FieldCategory.split(/<\/?br\s*\/?>/gi);

                                        return (
                                            <div className="workplacecontent" key={index}>
                                                <div className="d_header_section" style={{ display: 'flex', flexDirection: 'column' }}>
                                                    {parts[0] && <span style={{ fontWeight: "bold", textAlign: 'left', fontSize: '12px' }}>{parts[0].trim()}</span>}
                                                    {parts[1] && <span style={{ fontWeight: "bold", textAlign: 'left', fontSize: '10px' }}>{parts[1].trim()}</span>}
                                                </div>
                                                <h4 style={{ textAlign: 'left', marginTop: '4px' }}>{project?.FieldData}</h4>
                                            </div>
                                        );
                                    })}
                                </div>


                                <div>

                                </div>

                            </div>
                        </div>
                        <div className="chartcardbox attendence">
                            <div className="d_header_section">
                                <h4>{AttendanceData.chartDetails.Title}</h4>
                                <div>
                                    <span className="chartsdp">SDPS : 80</span>
                                </div>
                            </div>
                            <div className="chartattendeceprogresbar">
                                {AttendanceData?.chartData?.length > 0 ? (
                                    <div className="chartattendenceprogressvalue">
                                        <h3>
                                            <b>{AttendanceData.chartData[0]?.FieldData}%</b>
                                        </h3>
                                        <span>{AttendanceData.chartData[0]?.FieldCategory}</span>
                                    </div>
                                ) : (
                                    <div></div>
                                )}

                                {/* Progress Bar */}
                                {AttendanceData?.chartData?.length > 0 && (
                                    <div className='attendence_rightside'>
                                        <div className="Attendance-progress-container">
                                            <div
                                                className={`Attendance-progress-bar ${AttendanceData.chartData[0]?.FieldData === 100
                                                    ? "Attendance-progress-bar progress_success" // Green for 100%
                                                    : AttendanceData.chartData[0]?.FieldData >= 25 && AttendanceData.chartData[0]?.FieldData < 100
                                                        ? "Attendance-progress-bar progress_warning" // Orange for 25% to 99%
                                                        : "Attendance-progress-bar progress_danger" // Red for <25%
                                                    }`}
                                                role="progressbar"
                                                style={{
                                                    width: `${AttendanceData.chartData[0]?.FieldData}%`, // Dynamically set the width
                                                }}
                                                aria-valuenow={AttendanceData.chartData[0]?.FieldData} // Dynamically set the current progress value
                                                aria-valuemin="0"
                                                aria-valuemax="100"
                                            >
                                                <span className="sr-only">{`MTD: ${100}% Complete`}</span>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>


                            <div className="infoattendpanel">
                                {/* Check if chartData exists and has data */}
                                {AttendanceData?.chartData?.length > 0 ? (
                                    // Access the "This Week" data from the chartData array
                                    <div className="attendence_leftside">
                                        <h3>
                                            <b>{AttendanceData.chartData[1]?.FieldData}%</b>
                                        </h3>
                                        <span>{AttendanceData.chartData[1]?.FieldCategory}</span>
                                    </div>
                                ) : (
                                    <div className="no-data-message">
                                        <p style={{ textAlign: 'center', fontSize: '14px', fontWeight: 'bold' }}>
                                            No data available...
                                        </p>
                                    </div>
                                )}

                                {/* Progress Bar */}
                                {AttendanceData?.chartData?.length > 0 && (
                                    <div className='attendence_rightside'>
                                        <div className="Attendance-progress-container">
                                            <div
                                                className={`Attendance-progress-bar ${AttendanceData.chartData[1]?.FieldData === 100
                                                    ? "Attendance-progress-bar progress_success" // Green for 100%
                                                    : AttendanceData.chartData[1]?.FieldData >= 25 && AttendanceData.chartData[1]?.FieldData < 100
                                                        ? "Attendance-progress-bar progress_warning" // Orange for 25% to 99%
                                                        : "Attendance-progress-bar progress_danger" // Red for <25%
                                                    }`}
                                                role="progressbar"
                                                style={{
                                                    width: `${AttendanceData.chartData[1]?.FieldData}%`, // Dynamically set the width
                                                }}
                                                aria-valuenow={AttendanceData.chartData[1]?.FieldData} // Dynamically set the current progress value
                                                aria-valuemin="0"
                                                aria-valuemax="100"
                                            >
                                                <span className="sr-only">{`MTD: ${100}% Complete`}</span>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>


                        <div className="chartcardbox attendence">
                            <div className="d_header_section">
                                <h4>{LocalTestScoreData.chartDetails.Title}</h4>
                                <div>
                                    <span className="chartsdp">SDPS : 80</span>
                                </div>
                            </div>
                            <div className="chartattendeceprogresbar">
                                {/* Check if chartData exists and has data */}
                                {LocalTestScoreData?.chartData?.length > 0 ? (
                                    // Access the "This Week" data from the chartData array
                                    <div className="chartattendenceprogressvalue">
                                        <h3>
                                            <b>{LocalTestScoreData.chartData[0]?.FieldData}%</b>
                                        </h3>
                                        <span>{LocalTestScoreData.chartData[0]?.FieldCategory}</span>
                                    </div>
                                ) : (
                                    <div></div>
                                )}

                                {/* Progress Bar */}
                                {LocalTestScoreData?.chartData?.length > 0 && (
                                    <div className='attendence_rightside'>
                                        <div className="Attendance-progress-container">
                                            <div
                                                className={`Attendance-progress-bar ${LocalTestScoreData.chartData[0]?.FieldData === 100
                                                    ? "Attendance-progress-bar progress_success" // Green for 100%
                                                    : LocalTestScoreData.chartData[0]?.FieldData >= 25 && LocalTestScoreData.chartData[0]?.FieldData < 100
                                                        ? "Attendance-progress-bar progress_warning" // Orange for 25% to 99%
                                                        : "Attendance-progress-bar progress_danger" // Red for <25%
                                                    }`}
                                                role="progressbar"
                                                style={{
                                                    width: `${LocalTestScoreData.chartData[0]?.FieldData}%`, // Dynamically set the width
                                                }}
                                                aria-valuenow={LocalTestScoreData.chartData[0]?.FieldData} // Dynamically set the current progress value
                                                aria-valuemin="0"
                                                aria-valuemax="100"
                                            >
                                                <span className="sr-only">{`MTD: ${100}% Complete`}</span>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>


                            <div className="chartattendeceprogresbar">
                                {/* Check if chartData exists and has data */}
                                {LocalTestScoreData?.chartData?.length > 0 ? (
                                    // Access the "This Week" data from the chartData array
                                    <div className="chartattendenceprogressvalue">
                                        <h3>
                                            <b>{LocalTestScoreData.chartData[1]?.FieldData}%</b>
                                        </h3>
                                        <span>{LocalTestScoreData.chartData[1]?.FieldCategory}</span>
                                    </div>
                                ) : (
                                    <div className="no-data-message">
                                        <p style={{ textAlign: 'center', fontSize: '14px', fontWeight: 'bold' }}>
                                            No data available...
                                        </p>
                                    </div>
                                )}

                                {/* Progress Bar */}
                                {LocalTestScoreData?.chartData?.length > 0 && (
                                    <div className='attendence_rightside'>
                                        <div className="Attendance-progress-container">
                                            <div
                                                className={`Attendance-progress-bar ${LocalTestScoreData.chartData[1]?.FieldData === 100
                                                    ? "Attendance-progress-bar progress_success"
                                                    : LocalTestScoreData.chartData[1]?.FieldData >= 25 && LocalTestScoreData.chartData[1]?.FieldData < 100
                                                        ? "Attendance-progress-bar progress_warning"
                                                        : "Attendance-progress-bar progress_danger"
                                                    }`}
                                                role="progressbar"
                                                style={{
                                                    width: `${LocalTestScoreData.chartData[1]?.FieldData}%`, // Dynamically set the width
                                                }}
                                                aria-valuenow={LocalTestScoreData.chartData[1]?.FieldData} // Dynamically set the current progress value
                                                aria-valuemin="0"
                                                aria-valuemax="100"
                                            >
                                                <span className="sr-only">{`MTD: ${100}% Complete`}</span>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                    </div>

                    {/* Box 4 */}
                    <div className="box4">
                        <div className="chartcardbox shortcuts">
                            <div className="d_header_section" style={{ paddingBottom: '15px' }}>
                                <h4>Short cuts</h4>
                            </div>
                            <div className="shortcut_menu">
                                <div className="shortcut_iconbg">
                                    <a
                                        href="https://outlook.office.com/mail/"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        data-tooltip-id="mailTooltip"
                                    >
                                        <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAaCAYAAABCfffNAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAF8SURBVHgB7VVLUsJAFOwJyDp4gnAD2bkQCo7gDeAEDCegOIHjCdATyA1IqWW5gxuQG5g9n7FfgJSSSMJnYSm9SF6SN69f93wCnPEvoTaB29CeWmDANx6OhUVgZ2iH7yaQx2L8YUXQwCnARtUF6wHNbyTKoQIbhRNr0WccYl8ouLx2lDT7xZFiSuoVk+7I1w9fzANywr3RDRnH0Nv+5iSbwaMkcsDgsqYH7rX2dhbnXJZrekQnRjKOzd1nkiznhZ51UGEYWIWWKmHs1rROJah3O2qJscwlLfbtHFVWNJkkgtA3wcezqXBgWx7FhnJdTzeqxJqoe9ioIPO6tLYZvplJWr1UkpiMc0JVTbuxsIRpbM2q+6GoZp7ZVaeIDIgq3lq0zKei3nqZB3bJffBqfOSAg5wQVWsLb9l9NS+BIFNJCtkQeyK3kmPwd0iSc1JYVLkPKjgUCx4r6gcSLslAqeg4edpOOgg87hMkKKBtedyrE/xPuMwnmKGLM34tPgGiLobZO+AwuAAAAABJRU5ErkJggg==' alt="mailicon" />
                                    </a>
                                    <Tooltip id="mailTooltip" place="top" content="Open Outlook Mail" />
                                </div>
                                <div>Web mail</div>
                            </div>
                            <div className="shortcut_menu">
                                <div className="shortcut_iconbg">
                                    <a href="https://arc.accesshealthcare.co/arc_rewards/Home.aspx"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        data-tooltip-id="rewardTooltip"
                                    >
                                         <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAWCAYAAAAinad/AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAIZSURBVHgBjVXBcdswEFwgit9UKqA6yDOPWKEqiN0BXYGRCmxVYKYCOxUoqUC0ncnkF5WgCmI+M3IseO8ISjQFWtoZDkngsNy9w4EGHSSZS/APCfag+l0su2Nmh+zYzYzBCfbArzGpfhZle2zQIcoDURWuGER1YiyueR9FldFeataY8zH1HmfVfXETZWIaGPdH4rh4+veuuGzm7ObB40ICeC36iARVWVS0eKZWgfPkg0tfkIkqqsk1YIVTvAKm4kRyRaJvavet2t2SBXvieRqrUoN3n9w1czojoeNKJ0K5KJMPKFky/nIe7C0b/6K0Lb8hCuorPKFUux5TFWFwJbm0Bj4Pqn40RKLUHGHeELaJ/H9uiV/FQvN3XxSoq57yA5kRiSJdA21d6mD7vajlXBkj0g+P3QVFXErcw10xsmT/zuBS5uwTrlS+xYTvsijtJRIHNZEUbbIpAN5oqStvkCcfXdYh3CEK6mdK5HHTFE3JuHjJUn/VIO5sSWZDGCOSTmnSgMe6CCHvWwzH7kFiOVisVzX5DiznB6pqp1Ne9CYnF0x4RpWO1XTYB09lLQx6wpZ4HWlsMEomvdc9XtpgzubioDtucQD0wDwAg14CbhFr8Zn5y7FGMjx2dXM/6p48nIzbQxvfb4e0oVnlDEfhPYJem9IVJJtyd4/YKkO+n4ZjR4iS/coMbrngFqvtrt5IY9vxJpeeaYj8J54Bfu8F9Vi6feQAAAAASUVORK5CYII=' alt="rewardicon" />
                                    </a>
                                    <Tooltip id="rewardTooltip" place="top" content="Open reward" />
                                </div>
                                <div>Rewards</div>
                            </div>

                            <div className="shortcut_menu">
                                {/* Notification Count */}
                                {knolnotificationcount?.UnReadCount > 0 && (
                                    <div className="notification-badge">
                                        {knolnotificationcount.UnReadCount}
                                    </div>
                                )}
                                <div className="shortcut_iconbg">
                                    <a href="https://knolui.accesshealthcare.co/#/login"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        data-tooltip-id="knolTooltip"
                                    >
                                       <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAXCAYAAADgKtSgAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEuSURBVHgB7VVLTsMwEH0TIsTSvYE5AjsW0OYIHAFu4Bu03CCcgB4BbpB2xY7coD0BmB0SJcPkY4gqu7WQKlVqn5TEHr15Y0/kZ2CHoPqlMqPwCeVlnMHaIrfr4ZgcqklU4VVCGiEwCv7CnX3Jl+rKZEQYy7IyhLHkBBe1uBbxhQt6iNoNiDFlwm03td3j5fPqRKf9au/z/Hyd2Wy/gpH+jZ2wjB+qBBNfuwYjs5CdNgVSbEEnMFHXZkRtK8q3eW4QgQSxIMzqDwPPsSnx4v/AUfwofgjifeOycvzKAM+Kn9jGWxhP3M61X7F1S2dczt3UJhvlv+QbwlZYnH5/uMtCY7XBzxNktSv2Ct2LUxZBforS55hBqKGZDoaGxR0fY3Pifyj/rnSGXUBdSvv2BT/wLGYmCKvX9gAAAABJRU5ErkJggg==' alt="knolicon" />
                                    </a>
                                    <Tooltip id="knolTooltip" place="top" content="Open knol" />
                                </div>
                                <div>.knol</div>
                            </div>


                            <div className="shortcut_menu">
                                <div className="shortcut_iconbg">
                                    <a href="https://arc.accesshealthcare.co/arc_lounge/index.aspx"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        data-tooltip-id="forumTooltip"
                                    >
                                       <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAZCAYAAAArK+5dAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEmSURBVHgB3ZTRrYIwFIb/Eu577wYdgQWu0Q3uCDqBOIFxgzoBuoEbaPTFMbqBfTaRelqFEEQoSXnQLyHQ0p4fzul/gE+HFQ98nPIoxzw3EL6bIwadX7HWZ6nerYlLpRx7AySMwRtj9/0godukU4BI3CaDGTyhj8koB+O2NXF9Qp/kBp78jtKsa02MgPC/NKvXJagApWxar0uEIajUZRiBCoMLvNSADCdwwxKBeBGwhqMcCnhCvlyjjwAh6FJkuBW60ZeT3KGngDJXTNr6SxN8tJg/mke7QBncmgY94jOY/6YXcVNwO7CmQQDKY1pPCxVviwC0NmdKk/1tDp9AzB1tUYwvR8k6Bfpg/eOO+FOkEAjmZH2QykSuwanqfNBW8U4kOK7dfA13ashgE4UqqVsAAAAASUVORK5CYII=' alt="forumicon" />
                                    </a>
                                    <Tooltip id="forumTooltip" place="top" content="Open forum" />
                                </div>
                                <div>Forum</div>
                            </div>
                            <div className="shortcut_menu">
                                <div className="shortcut_iconbg">
                                    <a href="https://arc.accesshealthcare.co/bireports/LeaveApplication/LeaveRequest"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        data-tooltip-id="leaveTooltip"
                                    >
                                       <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAXCAYAAADgKtSgAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEuSURBVHgB7VVLTsMwEH0TIsTSvYE5AjsW0OYIHAFu4Bu03CCcgB4BbpB2xY7coD0BmB0SJcPkY4gqu7WQKlVqn5TEHr15Y0/kZ2CHoPqlMqPwCeVlnMHaIrfr4ZgcqklU4VVCGiEwCv7CnX3Jl+rKZEQYy7IyhLHkBBe1uBbxhQt6iNoNiDFlwm03td3j5fPqRKf9au/z/Hyd2Wy/gpH+jZ2wjB+qBBNfuwYjs5CdNgVSbEEnMFHXZkRtK8q3eW4QgQSxIMzqDwPPsSnx4v/AUfwofgjifeOycvzKAM+Kn9jGWxhP3M61X7F1S2dczt3UJhvlv+QbwlZYnH5/uMtCY7XBzxNktSv2Ct2LUxZBforS55hBqKGZDoaGxR0fY3Pifyj/rnSGXUBdSvv2BT/wLGYmCKvX9gAAAABJRU5ErkJggg==' alt="leaveicon" />
                                    </a>
                                    <Tooltip id="leaveTooltip" place="top" content="Open leave apply" />
                                </div>
                                <div>Leave</div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    );
};

export default HomeDashBoard;